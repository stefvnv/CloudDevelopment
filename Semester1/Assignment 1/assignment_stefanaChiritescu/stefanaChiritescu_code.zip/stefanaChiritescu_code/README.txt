15/11/2021
----------

This application reads the users' day born, month born, year born, and calculates and outputs the Astrological and Chinese Zodiac Signs.

To run the application, run the 'Calculator.py' file and make sure Python is installed on your system.


!!!NOTICE!!!
------------
Python v3.10 is needed to run this application as it uses a match case.


https://www.python.org/downloads/release/python-3100/





--------------------------
© Stefana Chiritescu, 2021